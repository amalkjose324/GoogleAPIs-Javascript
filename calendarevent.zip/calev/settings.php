<?php

/* Google App Client Id */
define('CLIENT_ID', '369962214050-qv2v67bd272rg9ln2ukfnktdbfn8t3f7.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'Ri9pRSVnuLB9k_XmZ5oepw6Y');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost:8082/googleapi/calev/google-login.php');

?>